## Visionary_S_CX_SIM4000_ConnectionSample
Establish the connection from SIM to up to 4 Visionary-S CX devices and show the PointClouds in SOPASair

### Description
Establish the connection from SIM to up to 4 Visionary-S CX devices and show the PointClouds in SOPASair

### How to run
Set up the IP addresses of the Visionary-S CX devices respective the multiple networks of the SIM.
Connect SIM to PC and Visionary-S CX devices driectly to the network interfaces of the SIM.
Start by running the app (F5) or debugging (F7+F10).
Set a breakpoint on the first row inside the main function to debug step-by-step.
See the results in the viewer on the DevicePage.

### Topics
View, Visionary, Stereo, Sample, SICK-AppSpace, SIM
